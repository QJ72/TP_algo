##Rendu TP Quentin Jouanjan

#TP liste : terminé
#TP arbre binaire de recherche : terminé sans fonctions optionnelles
#TP tas : en cours
#TP queue : terminé
#TP pile : terminé
